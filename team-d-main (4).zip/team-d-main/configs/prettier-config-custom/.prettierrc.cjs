// Project prettier configuration

module.exports = {
    singleQuote: true,
    semi: true,
    tabWidth: 4,
    printWidth: 100,
    trailingComma: 'es5',
};
