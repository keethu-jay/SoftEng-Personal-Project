module.exports = 'prettier-config-custom/.prettierrc.cjs';
