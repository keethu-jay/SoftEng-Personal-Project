// import { Graph } from '../src/bfs.ts';
//
// const graph = new Graph();
// graph.loadNodesFromCSV('../database/nodes.csv');
// graph.loadEdgesFromCSV('../database/edges.csv');
//
// const path = graph.bfs('NodeA', 'NodeD');
// console.log('Path from NodeA to NodeD:', path);
