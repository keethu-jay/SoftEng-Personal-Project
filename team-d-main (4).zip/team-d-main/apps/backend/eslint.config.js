import customConfig from 'eslint-config-custom';

export default customConfig;
