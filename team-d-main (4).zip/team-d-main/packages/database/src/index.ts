export * from '../.prisma/client';
